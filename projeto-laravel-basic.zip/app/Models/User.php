<?php

namespace App\Models;

use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable implements JWTSubject
{
    protected $attributes = [
        'confirmed' => false,
        'active'    => true,
    ];
    public $timestamps    = false;

    function passwordHash(string $password): string
    {
        return bcrypt($password);
    }

    public function userPlans()
    {
        return $this->hasMany(UserPlan::class, 'user_id', 'id');
    }

    public function students()
    {
        return $this->hasMany(Student::class, 'user_id', 'id');
    }

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
}
